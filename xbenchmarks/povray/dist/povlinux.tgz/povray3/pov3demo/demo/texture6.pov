// Persistence Of Vision raytracer version 3.0 sample file.
// The TEXTUREn.POV files demonstrate all textures in TEXTURES.INC
// and STONES.INC

#version 3.0
global_settings { assumed_gamma 2.2 }

#include "colors.inc"
#include "shapes.inc"
#include "textures.inc"
#include "stones.inc"

#declare T01 = texture {T_Stone9}
#declare T02 = texture{T_Stone10}
#declare T03 = texture{T_Stone11}

#declare T04 = texture{T_Stone12}
#declare T05 = texture{T_Stone13}
#declare T06 = texture{T_Stone14}

#declare T07 = texture{T_Stone15}
#declare T08 = texture{T_Stone16}
#declare T09 = texture{T_Stone17}

#declare T10 = texture{T_Stone18}
#declare T11 = texture{T_Stone19}
#declare T12 = texture{T_Stone20}

#declare T13 = texture{T_Stone21}
#declare T14 = texture{T_Stone22}
#declare T15 = texture{T_Stone23}

#declare T16 = texture{T_Stone24}
#declare T17 = texture{pigment {Clear}}
#declare T18 = texture{pigment {Clear}}

#declare T19 = texture{pigment {Clear}}
#declare T20 = texture{pigment {Clear}}
#declare T21 = texture{pigment {Clear}}

#declare T22 = texture{pigment {Clear}}
#declare T23 = texture{pigment {Clear}}
#declare T24 = texture{pigment {Clear}}

#declare T25 = texture{pigment {Clear}}
#declare T26 = texture{pigment {Clear}}
#declare T27 = texture{pigment {Clear}}

#include "shotxtr.inc"
