// Persistence Of Vision raytracer version 3.0 sample file.
// The TEXTUREn.POV files demonstrate all textures in TEXTURES.INC
// and STONES.INC

#version 3.0
global_settings { assumed_gamma 2.2 }

#include "colors.inc"
#include "shapes.inc"
#include "textures.inc"
#include "stones.inc"

#declare T01 = texture {T_Grnt13}
#declare T02 = texture {T_Grnt14}
#declare T03 = texture {T_Grnt15}

#declare T04 = texture {T_Grnt16}
#declare T05 = texture {T_Grnt17}
#declare T06 = texture {T_Grnt18}

#declare T07 = texture {T_Grnt19}
#declare T08 = texture {T_Grnt20}
#declare T09 = texture {T_Grnt21}

#declare T10 = texture {T_Grnt22}
#declare T11 = texture {T_Grnt23}
#declare T12 = texture {T_Grnt24}

#declare T13 = texture {T_Grnt25}
#declare T14 = texture {T_Grnt26}
#declare T15 = texture {T_Grnt27}

#declare T16 = texture {T_Grnt28}
#declare T17 = texture {T_Grnt29}
#declare T18 = texture {T_Grnt0a}

#declare T19 = texture {T_Grnt1a}
#declare T20 = texture {T_Grnt2a}
#declare T21 = texture {T_Grnt3a}

#declare T22 = texture {T_Grnt4a}
#declare T23 = texture {T_Grnt5a}
#declare T24 = texture {T_Grnt6a}

#declare T25 = texture {T_Grnt7a}
#declare T26 = texture {T_Grnt8a}
#declare T27 = texture {T_Grnt9a}

#include "shotxtr.inc"
