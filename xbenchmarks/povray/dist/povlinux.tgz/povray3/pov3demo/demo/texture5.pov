// Persistence Of Vision raytracer version 3.0 sample file.
// The TEXTUREn.POV files demonstrate all textures in TEXTURES.INC
// and STONES.INC

#version 3.0
global_settings { assumed_gamma 2.2 }

#include "colors.inc"
#include "shapes.inc"
#include "textures.inc"
#include "stones.inc"

#declare T01 = texture {T_Grnt10a}
#declare T02 = texture {T_Grnt11a}
#declare T03 = texture {T_Grnt12a}

#declare T04 = texture {T_Grnt13a}
#declare T05 = texture {T_Grnt14a}
#declare T06 = texture {T_Grnt15a}

#declare T07 = texture {T_Grnt16a}
#declare T08 = texture {T_Grnt17a}
#declare T09 = texture {T_Grnt18a}

#declare T10 = texture {T_Grnt19a}
#declare T11 = texture {T_Grnt20a}
#declare T12 = texture {T_Grnt21a}

#declare T13 = texture {T_Grnt22a}
#declare T14 = texture {T_Grnt23a}
#declare T15 = texture {T_Grnt24a}

#declare T16 = texture {T_Crack1}
#declare T17 = texture {T_Crack2}
#declare T18 = texture {T_Crack3}

#declare T19 = texture {T_Crack4}
#declare T20 = texture {T_Stone1}
#declare T21 = texture {T_Stone2}

#declare T22 = texture {T_Stone3}
#declare T23 = texture {T_Stone4}
#declare T24 = texture {T_Stone5}

#declare T25 = texture {T_Stone6}
#declare T26 = texture {T_Stone7}
#declare T27 = texture {T_Stone8}

#include "shotxtr.inc"
