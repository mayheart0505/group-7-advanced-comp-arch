//
// POV-Ray(tm) 3.0 tutorial example scene.
// Copyright 1996 by the POV-Ray Team
//
 
#include "atmos1.pov"

atmosphere {
  type 1
  samples 50
  distance 40 
  scattering 0.2
  aa_level 4
  aa_threshold 0.1
  jitter 0.2
}

