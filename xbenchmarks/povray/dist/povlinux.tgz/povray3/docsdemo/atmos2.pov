//
// POV-Ray(tm) 3.0 tutorial example scene.
// Copyright 1996 by the POV-Ray Team
//
 
#include "atmos1.pov"

atmosphere {
  type 1
  samples 10
  distance 40 
  scattering 0.2
}

