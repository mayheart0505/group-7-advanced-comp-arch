//
// POV-Ray(tm) 3.0 tutorial example scene.
// Copyright 1996 by the POV-Ray Team
//
 
#include "fog.inc"

fog { 
  distance 150 
  colour rgbf<0.3, 0.5, 0.2, 1.0> 
  turbulence 0.2
  turb_depth 0.3
}

