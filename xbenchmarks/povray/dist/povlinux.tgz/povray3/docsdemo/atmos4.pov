//
// POV-Ray(tm) 3.0 tutorial example scene.
// Copyright 1996 by the POV-Ray Team
//
 
#include "atmos1.pov"

fog {
  distance 40 
  color rgb 0
}

