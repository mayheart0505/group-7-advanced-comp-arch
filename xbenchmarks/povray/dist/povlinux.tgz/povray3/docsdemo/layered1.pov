#include "colors.inc"

camera {
  location <0, 0, -6>
  look_at <0, 0, 0>
}

light_source { <-20, 30, -100> color White }
light_source { <10, 30, -10> color White }
light_source { <0, 30, 10> color White }

#declare PLAIN_TEXTURE =  
  // red/white check
  texture {
    pigment {
      checker
      color rgb<1.000, 0.000, 0.000> 
      color rgb<1.000, 1.000, 1.000>  
      scale <0.2500, 0.2500, 0.2500>
    }
  }

// plain red/white check box

box { <-1, -1, -1>, <1, 1, 1>
  texture {
    PLAIN_TEXTURE
  }
  translate  <-1.5, 1.2, 0>
}
